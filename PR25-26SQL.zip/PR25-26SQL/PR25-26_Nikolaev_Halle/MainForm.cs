﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PR25_26_Nikolaev_Halle
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dekanatSQLDataSet26NH.студенты". При необходимости она может быть перемещена или удалена.
            this.студентыTableAdapter.Fill(this.dekanatSQLDataSet26NH.студенты);
        }

        private void toolSave_Click(object sender, EventArgs e)
        {
            this.студентыTableAdapter.Update(this.dekanatSQLDataSet26NH);
        }

        private void dataGridViewDekan_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            var result = MessageBox.Show("Удалить запись?","Удаление",MessageBoxButtons.OKCancel, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
            if (result == DialogResult.Cancel) {
                e.Cancel = true;
            }
        }

        private void AddNewItem_Click(object sender, EventArgs e)
        {
            
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
AddStudForm addform = new AddStudForm();
            addform.Owner= this;
            addform.Show();
        }
    }
}
