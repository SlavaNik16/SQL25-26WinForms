﻿namespace PR25_26_Nikolaev_Halle
{
    partial class AddStudForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label кодСтудентаLabel;
            System.Windows.Forms.Label кодГруппыLabel;
            System.Windows.Forms.Label фамилияLabel;
            System.Windows.Forms.Label имяLabel;
            System.Windows.Forms.Label отчествоLabel;
            System.Windows.Forms.Label полLabel;
            System.Windows.Forms.Label датаРождLabel;
            System.Windows.Forms.Label место_рожденияLabel;
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.Add = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.группыСтудентовBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dekanatSQLDataSet26NH = new PR25_26_Nikolaev_Halle.dekanatSQLDataSet26NH();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.группыСтудентовTableAdapter = new PR25_26_Nikolaev_Halle.dekanatSQLDataSet26NHTableAdapters.ГруппыСтудентовTableAdapter();
            this.Close = new System.Windows.Forms.Button();
            кодСтудентаLabel = new System.Windows.Forms.Label();
            кодГруппыLabel = new System.Windows.Forms.Label();
            фамилияLabel = new System.Windows.Forms.Label();
            имяLabel = new System.Windows.Forms.Label();
            отчествоLabel = new System.Windows.Forms.Label();
            полLabel = new System.Windows.Forms.Label();
            датаРождLabel = new System.Windows.Forms.Label();
            место_рожденияLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.группыСтудентовBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dekanatSQLDataSet26NH)).BeginInit();
            this.SuspendLayout();
            // 
            // кодСтудентаLabel
            // 
            кодСтудентаLabel.AutoSize = true;
            кодСтудентаLabel.Location = new System.Drawing.Point(38, 59);
            кодСтудентаLabel.Name = "кодСтудентаLabel";
            кодСтудентаLabel.Size = new System.Drawing.Size(56, 13);
            кодСтудентаLabel.TabIndex = 9;
            кодСтудентаLabel.Text = "Студента:";
            // 
            // кодГруппыLabel
            // 
            кодГруппыLabel.AutoSize = true;
            кодГруппыLabel.Location = new System.Drawing.Point(37, 102);
            кодГруппыLabel.Name = "кодГруппыLabel";
            кодГруппыLabel.Size = new System.Drawing.Size(50, 13);
            кодГруппыLabel.TabIndex = 10;
            кодГруппыLabel.Text = " Группы:";
            // 
            // фамилияLabel
            // 
            фамилияLabel.AutoSize = true;
            фамилияLabel.Location = new System.Drawing.Point(38, 152);
            фамилияLabel.Name = "фамилияLabel";
            фамилияLabel.Size = new System.Drawing.Size(59, 13);
            фамилияLabel.TabIndex = 11;
            фамилияLabel.Text = "Фамилия:";
            // 
            // имяLabel
            // 
            имяLabel.AutoSize = true;
            имяLabel.Location = new System.Drawing.Point(38, 201);
            имяLabel.Name = "имяLabel";
            имяLabel.Size = new System.Drawing.Size(32, 13);
            имяLabel.TabIndex = 12;
            имяLabel.Text = "Имя:";
            // 
            // отчествоLabel
            // 
            отчествоLabel.AutoSize = true;
            отчествоLabel.Location = new System.Drawing.Point(38, 249);
            отчествоLabel.Name = "отчествоLabel";
            отчествоLabel.Size = new System.Drawing.Size(57, 13);
            отчествоLabel.TabIndex = 13;
            отчествоLabel.Text = "Отчество:";
            // 
            // полLabel
            // 
            полLabel.AutoSize = true;
            полLabel.Location = new System.Drawing.Point(38, 301);
            полLabel.Name = "полLabel";
            полLabel.Size = new System.Drawing.Size(30, 13);
            полLabel.TabIndex = 14;
            полLabel.Text = "Пол:";
            // 
            // датаРождLabel
            // 
            датаРождLabel.AutoSize = true;
            датаРождLabel.Location = new System.Drawing.Point(37, 354);
            датаРождLabel.Name = "датаРождLabel";
            датаРождLabel.Size = new System.Drawing.Size(66, 13);
            датаРождLabel.TabIndex = 15;
            датаРождLabel.Text = "Дата Рожд:";
            // 
            // место_рожденияLabel
            // 
            место_рожденияLabel.AutoSize = true;
            место_рожденияLabel.Location = new System.Drawing.Point(38, 408);
            место_рожденияLabel.Name = "место_рожденияLabel";
            место_рожденияLabel.Size = new System.Drawing.Size(94, 13);
            место_рожденияLabel.TabIndex = 16;
            место_рожденияLabel.Text = "место рождения:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(175, 59);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 17;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(175, 152);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 18;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(175, 198);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 19;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(175, 249);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 20;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(175, 408);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 21;
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(40, 467);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(81, 31);
            this.Add.TabIndex = 22;
            this.Add.Text = "Добавить";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(175, 354);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(100, 20);
            this.dateTimePicker1.TabIndex = 23;
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.группыСтудентовBindingSource;
            this.comboBox1.DisplayMember = "название";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(175, 102);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(100, 21);
            this.comboBox1.TabIndex = 24;
            this.comboBox1.ValueMember = "кодГруппы";
            // 
            // группыСтудентовBindingSource
            // 
            this.группыСтудентовBindingSource.DataMember = "ГруппыСтудентов";
            this.группыСтудентовBindingSource.DataSource = this.dekanatSQLDataSet26NH;
            // 
            // dekanatSQLDataSet26NH
            // 
            this.dekanatSQLDataSet26NH.DataSetName = "dekanatSQLDataSet26NH";
            this.dekanatSQLDataSet26NH.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(175, 301);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(100, 21);
            this.comboBox2.TabIndex = 25;
            // 
            // группыСтудентовTableAdapter
            // 
            this.группыСтудентовTableAdapter.ClearBeforeFill = true;
            // 
            // Close
            // 
            this.Close.Location = new System.Drawing.Point(175, 467);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(81, 31);
            this.Close.TabIndex = 26;
            this.Close.Text = "Закрыть";
            this.Close.UseVisualStyleBackColor = true;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // AddStudForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(748, 549);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(место_рожденияLabel);
            this.Controls.Add(датаРождLabel);
            this.Controls.Add(полLabel);
            this.Controls.Add(отчествоLabel);
            this.Controls.Add(имяLabel);
            this.Controls.Add(фамилияLabel);
            this.Controls.Add(кодГруппыLabel);
            this.Controls.Add(кодСтудентаLabel);
            this.Name = "AddStudForm";
            this.Text = "AddStudForm";
            this.Load += new System.EventHandler(this.AddStudForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.группыСтудентовBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dekanatSQLDataSet26NH)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private dekanatSQLDataSet26NH dekanatSQLDataSet26NH;
        private System.Windows.Forms.BindingSource группыСтудентовBindingSource;
        private dekanatSQLDataSet26NHTableAdapters.ГруппыСтудентовTableAdapter группыСтудентовTableAdapter;
        private System.Windows.Forms.Button Close;
    }
}