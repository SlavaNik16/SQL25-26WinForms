﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace PR25_26_Nikolaev_Halle
{
    public partial class AddStudForm : Form
    {
        public AddStudForm()
        {
            InitializeComponent();
        }

        private void студентыBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();

        }

        private void AddStudForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dekanatSQLDataSet26NH.ГруппыСтудентов". При необходимости она может быть перемещена или удалена.
            this.группыСтудентовTableAdapter.Fill(this.dekanatSQLDataSet26NH.ГруппыСтудентов);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dekanatSQLDataSet26NH.студенты". При необходимости она может быть перемещена или удалена.

        }

        private void кодГруппыTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            MainForm main = this.Owner as MainForm;
            if (main != null)
            {
                DataRow Row = main.dekanatSQLDataSet26NH.Tables[2].NewRow();
                int rc = main.dataGridViewDekan.RowCount + 1;
                Row[0] = textBox1.Text;
                Row[1]=comboBox1.SelectedValue.ToString();
                Row[2] = textBox2.Text;
                Row[3] = textBox3.Text;
                Row[4] = textBox4.Text;
                Row[5] = comboBox2.Text;
                Row[6] = dateTimePicker1.Text;
                Row[7] = textBox5.Text;

                main.dekanatSQLDataSet26NH.Tables[2].Rows.Add(Row);
                main.студентыTableAdapter.Update(main.dekanatSQLDataSet26NH.студенты);
                main.dekanatSQLDataSet26NH.Tables[2].AcceptChanges();
                main.dataGridViewDekan.Refresh();

            }
        }

        private void Close_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
